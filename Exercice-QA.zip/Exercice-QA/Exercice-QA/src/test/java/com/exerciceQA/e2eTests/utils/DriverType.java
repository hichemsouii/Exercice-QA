package com.exerciceQA.e2eTests.utils;

public enum DriverType {
	CHROME, FIREFOX, IE, EDGE;
}
